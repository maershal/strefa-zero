#pragma once
#include "app/application.hpp"
namespace strefa::app {
std::expected<int,std::string> validate_shader_cache(const std::filesystem::path&);
// nullopt means this is an interactive/window scenario.
std::optional<std::expected<int,std::string>> run_diagnostic_scenario(
    const LaunchOptions&,const std::filesystem::path& assets,const std::filesystem::path& profile);
}
