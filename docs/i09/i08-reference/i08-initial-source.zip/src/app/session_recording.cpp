#include "app/session_recording.hpp"
#include <cmath>
#include <fstream>
#include <iomanip>
#include <limits>
#include <sstream>

namespace strefa::app {
namespace {
std::string configuration(const gpu::ExecutionOptions& e,const gpu::ProfileOptions& p){
    std::ostringstream out;
    out<<e.specialized<<' '<<e.cached_bindings<<' '<<e.fifo_queries<<' '<<e.conditional_work<<' '
        <<e.local_size<<' '<<e.reduction_size<<' '<<static_cast<int>(e.neighbors)<<' '<<e.soa<<' '
        <<static_cast<int>(e.coupling)<<' '<<e.phase_gating<<' '<<e.skip_zero_projection<<' '
        <<static_cast<int>(e.storage)<<' '<<static_cast<int>(e.neighbor_reads)<<' '
        <<e.pbf_size<<' '<<e.pbf_restrict<<' '<<p.body_coupling<<' '<<p.periodic_diagnostics;
    return out.str();
}
}
void SessionRecording::begin(){commands_.clear();commands_.reserve(capacity);active_=true;overflow_=false;}
void SessionRecording::append(SessionCommand command){
    if(!active_)return;
    if(commands_.size()==capacity){active_=false;overflow_=true;return;}
    commands_.push_back(std::move(command));
}
std::expected<void,std::string> SessionRecording::save(const std::filesystem::path& path,
    const gpu::ExecutionOptions& execution,const gpu::ProfileOptions& profile)const{
    if(overflow_)return std::unexpected{"Nagranie przekroczyło 65536 poleceń. Rozpocznij krótszą sesję."};
    if(commands_.empty())return std::unexpected{"Najpierw rozpocznij nagrywanie sceny."};
    std::ofstream out{path};if(!out)return std::unexpected{"Nie można zapisać scenariusza."};
    out<<"STREFA_SESSION 2\n"<<"I07.1 "<<gpu::fluid_configuration(execution.fluid)<<'\n'<<configuration(execution,profile)<<'\n'<<std::setprecision(std::numeric_limits<float>::max_digits10);
    for(const auto& command:commands_){
        if(const auto* scene=std::get_if<SceneConfiguration>(&command))out<<"R "<<scene->mission<<' '<<static_cast<int>(scene->laboratory)<<'\n';
        else if(const auto* stroke=std::get_if<gpu::Stroke>(&command))out<<"P "<<stroke->x0<<' '<<stroke->y0<<' '<<stroke->x1<<' '<<stroke->y1<<' '<<stroke->radius<<' '<<static_cast<int>(stroke->material)<<'\n';
        else{const auto& input=std::get<gpu::MissionInput>(command);out<<"T "<<input.move<<' '<<input.aim_x<<' '<<input.aim_y<<' '<<input.buttons<<'\n';}
    }
    if(!out)return std::unexpected{"Niepełny zapis scenariusza."};
    return {};
}
std::expected<std::vector<SessionCommand>,std::string> SessionRecording::load(const std::filesystem::path& path,
    const gpu::ExecutionOptions& execution,const gpu::ProfileOptions& profile){
    std::ifstream in{path};std::string line;
    if(!std::getline(in,line))return std::unexpected{"Nieznany format scenariusza."};
    if(line=="STREFA_SESSION 2"){
        if(!std::getline(in,line)||line!="I07.1 "+gpu::fluid_configuration(execution.fluid))
            return std::unexpected{"Nagranie wymaga tej samej rewizji i konfiguracji fizyki I07."};
    }else if(line=="STREFA_SESSION 1"){
        if(execution.fluid!=gpu::FluidOptions{})return std::unexpected{"Nagranie v1 wymaga profilu cieczy legacy."};
    }else return std::unexpected{"Nieznany format scenariusza."};
    if(!std::getline(in,line)||line!=configuration(execution,profile))return std::unexpected{"Scenariusz wymaga tej samej konfiguracji solvera."};
    std::vector<SessionCommand> commands;
    while(std::getline(in,line)){
        if(commands.size()==capacity||line.size()>512)return std::unexpected{"Scenariusz przekracza limit poleceń."};
        std::istringstream row{line};char kind{};row>>kind;
        if(kind=='R'){
            int mission{},scene{};
            if(!(row>>mission>>scene)||(mission!=0&&mission!=1)||scene<0||scene>11)return std::unexpected{"Nieprawidłowa scena w nagraniu."};
            commands.emplace_back(SceneConfiguration{mission!=0,static_cast<gpu::Scene>(scene)});
        }else if(kind=='P'){
            gpu::Stroke stroke;int material{};
            if(!(row>>stroke.x0>>stroke.y0>>stroke.x1>>stroke.y1>>stroke.radius>>material)||material<0||material>6
                ||!std::isfinite(stroke.x0)||!std::isfinite(stroke.y0)||!std::isfinite(stroke.x1)||!std::isfinite(stroke.y1)
                ||!std::isfinite(stroke.radius)||stroke.radius<1||stroke.radius>16)return std::unexpected{"Nieprawidłowy pędzel w nagraniu."};
            stroke.material=static_cast<gpu::Material>(material);commands.emplace_back(stroke);
        }else if(kind=='T'){
            gpu::MissionInput input;
            if(!(row>>input.move>>input.aim_x>>input.aim_y>>input.buttons)||!std::isfinite(input.move)
                ||!std::isfinite(input.aim_x)||!std::isfinite(input.aim_y)||std::abs(input.move)>1||input.buttons>31)
                return std::unexpected{"Nieprawidłowy krok w nagraniu."};
            commands.emplace_back(input);
        }else return std::unexpected{"Nieznane polecenie scenariusza."};
        std::string extra;if(row>>extra)return std::unexpected{"Nadmiarowe dane scenariusza."};
    }
    if(in.bad()||commands.empty()||!std::holds_alternative<SceneConfiguration>(commands.front()))return std::unexpected{"Niepełny scenariusz."};
    return commands;
}
}
